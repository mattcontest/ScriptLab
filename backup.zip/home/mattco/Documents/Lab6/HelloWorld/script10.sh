#!/bin/sh

bestStudent() {
    tmp="Diana Prince"
    echo "$tmp" #Use this to return
}

result=$(bestStudent)
echo $result



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